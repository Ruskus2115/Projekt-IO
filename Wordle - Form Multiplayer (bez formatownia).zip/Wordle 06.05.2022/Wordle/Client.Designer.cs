﻿namespace Wordle
{
    partial class Client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdSend = new System.Windows.Forms.Button();
            this.richTextBoxSender = new System.Windows.Forms.RichTextBox();
            this.cmdConnect = new System.Windows.Forms.Button();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.txtLog = new System.Windows.Forms.RichTextBox();
            this.richTextBoxGetter = new System.Windows.Forms.RichTextBox();
            this.txtIP = new System.Windows.Forms.TextBox();
            this.Connection = new System.ComponentModel.BackgroundWorker();
            this.Odbieranie = new System.ComponentModel.BackgroundWorker();
            this.SuspendLayout();
            // 
            // cmdSend
            // 
            this.cmdSend.Location = new System.Drawing.Point(703, 152);
            this.cmdSend.Name = "cmdSend";
            this.cmdSend.Size = new System.Drawing.Size(75, 23);
            this.cmdSend.TabIndex = 11;
            this.cmdSend.Text = "Send";
            this.cmdSend.UseVisualStyleBackColor = true;
            this.cmdSend.Click += new System.EventHandler(this.cmdSend_Click);
            // 
            // richTextBoxSender
            // 
            this.richTextBoxSender.Location = new System.Drawing.Point(12, 177);
            this.richTextBoxSender.Name = "richTextBoxSender";
            this.richTextBoxSender.ReadOnly = true;
            this.richTextBoxSender.Size = new System.Drawing.Size(100, 96);
            this.richTextBoxSender.TabIndex = 10;
            this.richTextBoxSender.Text = "";
            this.richTextBoxSender.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.richTextBoxSender_KeyPress);
            // 
            // cmdConnect
            // 
            this.cmdConnect.Location = new System.Drawing.Point(703, 123);
            this.cmdConnect.Name = "cmdConnect";
            this.cmdConnect.Size = new System.Drawing.Size(75, 23);
            this.cmdConnect.TabIndex = 9;
            this.cmdConnect.Text = "Connect";
            this.cmdConnect.UseVisualStyleBackColor = true;
            this.cmdConnect.Click += new System.EventHandler(this.cmdConnect_Click);
            // 
            // txtPort
            // 
            this.txtPort.Location = new System.Drawing.Point(688, 97);
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(100, 20);
            this.txtPort.TabIndex = 8;
            // 
            // txtLog
            // 
            this.txtLog.Location = new System.Drawing.Point(12, 279);
            this.txtLog.Name = "txtLog";
            this.txtLog.ReadOnly = true;
            this.txtLog.Size = new System.Drawing.Size(100, 96);
            this.txtLog.TabIndex = 7;
            this.txtLog.Text = "";
            // 
            // richTextBoxGetter
            // 
            this.richTextBoxGetter.Location = new System.Drawing.Point(12, 75);
            this.richTextBoxGetter.Name = "richTextBoxGetter";
            this.richTextBoxGetter.Size = new System.Drawing.Size(100, 96);
            this.richTextBoxGetter.TabIndex = 6;
            this.richTextBoxGetter.Text = "";
            // 
            // txtIP
            // 
            this.txtIP.Location = new System.Drawing.Point(688, 42);
            this.txtIP.Name = "txtIP";
            this.txtIP.Size = new System.Drawing.Size(100, 20);
            this.txtIP.TabIndex = 12;
            // 
            // Connection
            // 
            this.Connection.WorkerSupportsCancellation = true;
            this.Connection.DoWork += new System.ComponentModel.DoWorkEventHandler(this.Connection_DoWork);
            // 
            // Odbieranie
            // 
            this.Odbieranie.WorkerSupportsCancellation = true;
            this.Odbieranie.DoWork += new System.ComponentModel.DoWorkEventHandler(this.Odbieranie_DoWork);
            // 
            // Client
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtIP);
            this.Controls.Add(this.cmdSend);
            this.Controls.Add(this.richTextBoxSender);
            this.Controls.Add(this.cmdConnect);
            this.Controls.Add(this.txtPort);
            this.Controls.Add(this.txtLog);
            this.Controls.Add(this.richTextBoxGetter);
            this.Name = "Client";
            this.Text = "Client";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Client_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdSend;
        private System.Windows.Forms.RichTextBox richTextBoxSender;
        private System.Windows.Forms.Button cmdConnect;
        private System.Windows.Forms.TextBox txtPort;
        private System.Windows.Forms.RichTextBox txtLog;
        private System.Windows.Forms.RichTextBox richTextBoxGetter;
        private System.Windows.Forms.TextBox txtIP;
        private System.ComponentModel.BackgroundWorker Connection;
        private System.ComponentModel.BackgroundWorker Odbieranie;
    }
}