﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;
using communicates;

namespace Wordle
{
    public partial class Client : Form
    {
        private TcpClient klient = null;
        private bool czypolaczono = false;
        private BinaryReader r = null;
        private BinaryWriter w = null;
        public Client()
        {
            InitializeComponent();
        }

        public void show(RichTextBox o, string tekst)
        {
            o.Focus();
            o.AppendText(tekst);
            o.ScrollToCaret();
            richTextBoxGetter.Focus();
        }

        private void Connection_DoWork(object sender, DoWorkEventArgs e)
        {
            klient = new TcpClient();
            show(txtLog, "Próbuje się połączyć\n");
            klient.Connect(IPAddress.Parse(txtIP.Text), int.Parse(txtPort.Text));
            show(txtLog, "Połączenie nawiązane\nŻądam zezwolenia\n");
            NetworkStream stream = klient.GetStream();
            w = new BinaryWriter(stream);
            r = new BinaryReader(stream);
            w.Write(ClientMessages.Zadaj);
            if (r.ReadString() == ServerMessages.OK)
            {
                show(txtLog, "Połączono\n");
                czypolaczono = true;
                cmdSend.Enabled = true;
                Odbieranie.RunWorkerAsync();
            }
            else
            {
                show(txtLog, "Brak odpowiedzi\nRozlaczono\n");
                czypolaczono = false;
                if (klient != null) klient.Close();
                cmdSend.Enabled = false;
                cmdConnect.Text = "Połącz";
            }
        }

        private void Odbieranie_DoWork(object sender, DoWorkEventArgs e)
        {
            string tekst;
            while ((tekst = r.ReadString()) != ServerMessages.Rozlacz)
            {
                show(richTextBoxGetter, "===== Rozmówca =====\n" + tekst + '\n');
            }
            cmdSend.Enabled = false;
            show(txtLog, "Rozlaczono\n");
            cmdConnect.Text = "Połącz";
            czypolaczono = false;
            if (klient != null) klient.Close();
        }

        private void cmdSend_Click(object sender, EventArgs e)
        {
            if (cmdSend.Text == "Czekaj na połączenie")
            {
                Connection.RunWorkerAsync();
                cmdSend.Text = "Rozłącz";
            }
            else
            {
                if (czypolaczono)
                {
                    w.Write(ServerMessages.Rozlacz);
                    if (klient != null) klient.Close();
                    czypolaczono = false;
                }
                show(txtLog, "Rozlaczono\n");
                cmdSend.Text = "Czekaj na połączenie";
                cmdConnect.Enabled = false;
                Connection.CancelAsync();
                Odbieranie.CancelAsync();
            }
        }

        private void richTextBoxSender_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (cmdSend.Enabled && e.KeyChar == (char)13) cmdSend_Click(sender, e);
        }

        private void cmdConnect_Click(object sender, EventArgs e)
        {
            if (cmdConnect.Text == "Połącz")
            {
                Connection.RunWorkerAsync();
                cmdConnect.Text = "Rozłącz";
            }
            else
            {
                if (czypolaczono)
                {
                    w.Write(ClientMessages.Rozlacz);
                    klient.Close();
                    czypolaczono = false;
                }
                cmdConnect.Text = "Połącz";
                cmdSend.Enabled = false;
                show(txtLog, "Rozlaczono\n");
            }
        }

        private void Client_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (czypolaczono)
            {
                w.Write(ClientMessages.Rozlacz);
                klient.Close();
                czypolaczono = false;
            }
            Connection.CancelAsync();
            Odbieranie.CancelAsync();
        }
    }
}
