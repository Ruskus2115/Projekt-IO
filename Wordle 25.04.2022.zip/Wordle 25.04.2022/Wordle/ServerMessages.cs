﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace communicates
{
    public class ServerMessages
    {
        public const string OK = "OK";
        public const string Cancel = "Cancel";
        public const string Rozlacz = "Rozlacz";
    }

    public class ClientMessages
    {
        public const string Zadaj = "Zadaj";
        public const string Rozlacz = "Rozlacz";
    }
}
