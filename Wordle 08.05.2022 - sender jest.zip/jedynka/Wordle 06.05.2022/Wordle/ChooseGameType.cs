﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;
using communicates;

namespace Wordle
{
    public partial class ChooseGameType : Form
    {
        private TcpListener listener = null;
        private TcpClient klient = null;
        private bool czypolaczono = false;
        private BinaryReader r = null;
        private BinaryWriter w = null;

        public ChooseGameType()
        {
            InitializeComponent();
        }
        public void show(RichTextBox o, string tekst)
        {
            o.Focus();
            o.AppendText(tekst);
            o.ScrollToCaret();
            richTextBox1.Focus();
        }

        private void Connection_DoWork(object sender, DoWorkEventArgs e)
        {
            show(richTextBox2, "Czekam na połaczenie\n");
            listener = new TcpListener(int.Parse(textBox1.Text));
            listener.Start();
            while (!listener.Pending())
            {
                if (this.Connection.CancellationPending)
                {
                    if (klient != null) klient.Close();
                    listener.Stop();
                    czypolaczono = false;
                    button1.Text = "Czekaj na połączenie";
                    return;
                }
            }

            klient = listener.AcceptTcpClient();
            show(richTextBox2, "Zażądano połączenia\n");
            NetworkStream stream = klient.GetStream();
            w = new BinaryWriter(stream);
            r = new BinaryReader(stream);
            if (r.ReadString() == ClientMessages.Zadaj)
            {
                w.Write(ServerMessages.OK);
                show(richTextBox2, "Połączono\n");
                czypolaczono = true;
                button1.Enabled = true;
                Odbieranie.RunWorkerAsync();
            }
            else
            {
                show(richTextBox2, "Klient odrzucony\nRozlaczono\n");
                if (klient != null) klient.Close();
                listener.Stop();
                czypolaczono = false;
            }
        }

        private void Odbieranie_DoWork(object sender, DoWorkEventArgs e)
        {
            string tekst;
            while ((tekst = r.ReadString()) != ClientMessages.Rozlacz)
            {
                show(richTextBox3, "===== Rozmówca =====\n" + tekst + '\n');
            }
            show(richTextBox2, "Rozlaczono\n");
            czypolaczono = false;
            klient.Close();
            listener.Stop();
            button1.Text = "Czekaj na połączenie";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string tekst = richTextBox1.Text;
            if (tekst == "") { richTextBox1.Focus(); return; }
            if (tekst[tekst.Length - 1] == '\n')
                tekst = tekst.TrimEnd('\n');
            w.Write(tekst);
            show(richTextBox3, "===== Ja =====\n" + tekst + '\n');
            richTextBox1.Text = "";
        }

        private void richTextBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (button1.Enabled && e.KeyChar == (char)13) button1_Click(sender, e);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (button2.Text == "Czekaj na połączenie")
            {
                Connection.RunWorkerAsync();
                button2.Text = "Rozłącz";
            }
            else
            {
                if (czypolaczono)
                {
                    w.Write(ServerMessages.Rozlacz);
                    listener.Stop();
                    if (klient != null) klient.Close();
                    czypolaczono = false;
                }
               show(richTextBox2, "Rozlaczono\n");
                button2.Text = "Czekaj na połączenie";
                button1.Enabled = false;
                Connection.CancelAsync();
                Odbieranie.CancelAsync();
            }
        }

        private void ChooseGameType_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (czypolaczono)
            {
                w.Write(ServerMessages.Rozlacz);
                listener.Stop();
                if (klient != null) klient.Close();
                czypolaczono = false;
            }
            Connection.CancelAsync();
            Odbieranie.CancelAsync();
        }
    }
}
