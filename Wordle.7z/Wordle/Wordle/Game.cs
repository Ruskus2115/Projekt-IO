﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wordle
{
    public partial class Game : Form
    {
        private SqlConnection con = new SqlConnection("Data Source =bmw-io.database.windows.net; Initial Catalog=SlowkaIO; User ID=bmw; Password=Azure321?");
        private SqlCommand cmd = new SqlCommand();
        private Random gen = new Random();
        private const int fieldSize = 20;
        private GameTextBox[,] gameFields;
        private int gameWidth, gameHeight;


        public Game() 
        {
            InitializeComponent();
            con.Open();
            SqlCommand cmd = new SqlCommand("select word from words ORDER BY NEWID()", con);
            string result = (string)cmd.ExecuteScalar();
            PrepareNewGame(result.Length, 6);
        }
        
        private void PrepareNewGame(int gameWidth, int gameHeight)
        {
            this.gameWidth = gameHeight;
            this.gameHeight = gameWidth;
            gameFields = new GameTextBox[gameWidth, gameHeight];

            for (int x = 0; x < gameWidth; x++)
            {
                for (int y = 0; y < gameHeight; y++)
                {
                    GameTextBox b = new GameTextBox();
                    if (y > 0)
                    {
                        b.Enabled = false;
                    }
                    b.MaxLength = 1;
                    b.TextAlign = HorizontalAlignment.Center;
                    b.Position = new Point(x, y);
                    b.BackColor = Color.Black;
                    b.ForeColor = Color.White;
                    b.Size = new Size(fieldSize, fieldSize);
                    b.Location = new Point(x * fieldSize, y * fieldSize);
                    gameFields[x, y] = b;
                    panelGame.Controls.Add(b);
                    b.Focus();
                }
            }
        }
    }
}