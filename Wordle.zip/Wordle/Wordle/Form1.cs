﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wordle
{
    public partial class Form1 : Form
    {
        private SqlConnection con = new SqlConnection("Data Source =bmw-io.database.windows.net; Initial Catalog=SlowkaIO; User ID=bmw; Password=Azure321?");
        private SqlCommand cmd = new SqlCommand();
        Game g = new Game();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string username = textBoxUsername.Text;
            string email = textBoxEmail.Text;
            string password = textBoxPassword.Text;
            //cmd.CommandText = "insert into Accounts (email,nick,password) values ('" + email + "','" + username + "','" + password + "')";


            SqlCommand cmd = new SqlCommand("select id_user from accounts where email='"+email+"' AND nick='"+username+ "' AND password='"+password+"'", con);
            int result = Convert.ToInt32(cmd.ExecuteScalar());

            if (result != 0)
            {
                MessageBox.Show("Logged");
                this.Hide();
                g.Location = this.Location;
                g.Show();
            }
            else
            {
                MessageBox.Show("Podane konto nie istnieje.\nCzy chcesz je teraz utworzyć? ", "Error",MessageBoxButtons.YesNo);
            }
        }
    }
}
