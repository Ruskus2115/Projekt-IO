﻿namespace Wordle
{
    partial class Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonEnter = new System.Windows.Forms.Button();
            this.buttonM = new System.Windows.Forms.Button();
            this.buttonL = new System.Windows.Forms.Button();
            this.buttonN = new System.Windows.Forms.Button();
            this.buttonK = new System.Windows.Forms.Button();
            this.buttonB = new System.Windows.Forms.Button();
            this.buttonV = new System.Windows.Forms.Button();
            this.buttonJ = new System.Windows.Forms.Button();
            this.buttonC = new System.Windows.Forms.Button();
            this.buttonH = new System.Windows.Forms.Button();
            this.buttonX = new System.Windows.Forms.Button();
            this.buttonG = new System.Windows.Forms.Button();
            this.buttonZ = new System.Windows.Forms.Button();
            this.buttonF = new System.Windows.Forms.Button();
            this.buttonD = new System.Windows.Forms.Button();
            this.buttonS = new System.Windows.Forms.Button();
            this.buttonA = new System.Windows.Forms.Button();
            this.buttonP = new System.Windows.Forms.Button();
            this.buttonO = new System.Windows.Forms.Button();
            this.buttonI = new System.Windows.Forms.Button();
            this.buttonU = new System.Windows.Forms.Button();
            this.buttonY = new System.Windows.Forms.Button();
            this.buttonT = new System.Windows.Forms.Button();
            this.buttonR = new System.Windows.Forms.Button();
            this.buttonE = new System.Windows.Forms.Button();
            this.buttonW = new System.Windows.Forms.Button();
            this.buttonQ = new System.Windows.Forms.Button();
            this.panelGame = new System.Windows.Forms.Panel();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonEnter);
            this.groupBox1.Controls.Add(this.buttonM);
            this.groupBox1.Controls.Add(this.buttonL);
            this.groupBox1.Controls.Add(this.buttonN);
            this.groupBox1.Controls.Add(this.buttonK);
            this.groupBox1.Controls.Add(this.buttonB);
            this.groupBox1.Controls.Add(this.buttonV);
            this.groupBox1.Controls.Add(this.buttonJ);
            this.groupBox1.Controls.Add(this.buttonC);
            this.groupBox1.Controls.Add(this.buttonH);
            this.groupBox1.Controls.Add(this.buttonX);
            this.groupBox1.Controls.Add(this.buttonG);
            this.groupBox1.Controls.Add(this.buttonZ);
            this.groupBox1.Controls.Add(this.buttonF);
            this.groupBox1.Controls.Add(this.buttonD);
            this.groupBox1.Controls.Add(this.buttonS);
            this.groupBox1.Controls.Add(this.buttonA);
            this.groupBox1.Controls.Add(this.buttonP);
            this.groupBox1.Controls.Add(this.buttonO);
            this.groupBox1.Controls.Add(this.buttonI);
            this.groupBox1.Controls.Add(this.buttonU);
            this.groupBox1.Controls.Add(this.buttonY);
            this.groupBox1.Controls.Add(this.buttonT);
            this.groupBox1.Controls.Add(this.buttonR);
            this.groupBox1.Controls.Add(this.buttonE);
            this.groupBox1.Controls.Add(this.buttonW);
            this.groupBox1.Controls.Add(this.buttonQ);
            this.groupBox1.Location = new System.Drawing.Point(333, 548);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(295, 121);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // buttonEnter
            // 
            this.buttonEnter.Location = new System.Drawing.Point(218, 79);
            this.buttonEnter.Name = "buttonEnter";
            this.buttonEnter.Size = new System.Drawing.Size(50, 26);
            this.buttonEnter.TabIndex = 83;
            this.buttonEnter.Text = "Enter";
            this.buttonEnter.UseVisualStyleBackColor = true;
            this.buttonEnter.Click += new System.EventHandler(this.buttonEnter_Click);
            // 
            // buttonM
            // 
            this.buttonM.Location = new System.Drawing.Point(190, 79);
            this.buttonM.Name = "buttonM";
            this.buttonM.Size = new System.Drawing.Size(22, 26);
            this.buttonM.TabIndex = 82;
            this.buttonM.Text = "M";
            this.buttonM.UseVisualStyleBackColor = true;
            // 
            // buttonL
            // 
            this.buttonL.Location = new System.Drawing.Point(246, 47);
            this.buttonL.Name = "buttonL";
            this.buttonL.Size = new System.Drawing.Size(22, 26);
            this.buttonL.TabIndex = 75;
            this.buttonL.Text = "L";
            this.buttonL.UseVisualStyleBackColor = true;
            // 
            // buttonN
            // 
            this.buttonN.Location = new System.Drawing.Point(163, 79);
            this.buttonN.Name = "buttonN";
            this.buttonN.Size = new System.Drawing.Size(22, 26);
            this.buttonN.TabIndex = 81;
            this.buttonN.Text = "N";
            this.buttonN.UseVisualStyleBackColor = true;
            // 
            // buttonK
            // 
            this.buttonK.Location = new System.Drawing.Point(218, 47);
            this.buttonK.Name = "buttonK";
            this.buttonK.Size = new System.Drawing.Size(22, 26);
            this.buttonK.TabIndex = 74;
            this.buttonK.Text = "K";
            this.buttonK.UseVisualStyleBackColor = true;
            // 
            // buttonB
            // 
            this.buttonB.Location = new System.Drawing.Point(135, 79);
            this.buttonB.Name = "buttonB";
            this.buttonB.Size = new System.Drawing.Size(22, 26);
            this.buttonB.TabIndex = 80;
            this.buttonB.Text = "B";
            this.buttonB.UseVisualStyleBackColor = true;
            // 
            // buttonV
            // 
            this.buttonV.Location = new System.Drawing.Point(107, 79);
            this.buttonV.Name = "buttonV";
            this.buttonV.Size = new System.Drawing.Size(22, 26);
            this.buttonV.TabIndex = 79;
            this.buttonV.Text = "V";
            this.buttonV.UseVisualStyleBackColor = true;
            // 
            // buttonJ
            // 
            this.buttonJ.Location = new System.Drawing.Point(190, 47);
            this.buttonJ.Name = "buttonJ";
            this.buttonJ.Size = new System.Drawing.Size(22, 26);
            this.buttonJ.TabIndex = 73;
            this.buttonJ.Text = "J";
            this.buttonJ.UseVisualStyleBackColor = true;
            // 
            // buttonC
            // 
            this.buttonC.Location = new System.Drawing.Point(79, 79);
            this.buttonC.Name = "buttonC";
            this.buttonC.Size = new System.Drawing.Size(22, 26);
            this.buttonC.TabIndex = 78;
            this.buttonC.Text = "C";
            this.buttonC.UseVisualStyleBackColor = true;
            // 
            // buttonH
            // 
            this.buttonH.Location = new System.Drawing.Point(163, 47);
            this.buttonH.Name = "buttonH";
            this.buttonH.Size = new System.Drawing.Size(22, 26);
            this.buttonH.TabIndex = 72;
            this.buttonH.Text = "H";
            this.buttonH.UseVisualStyleBackColor = true;
            // 
            // buttonX
            // 
            this.buttonX.Location = new System.Drawing.Point(51, 79);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(22, 26);
            this.buttonX.TabIndex = 77;
            this.buttonX.Text = "X";
            this.buttonX.UseVisualStyleBackColor = true;
            // 
            // buttonG
            // 
            this.buttonG.Location = new System.Drawing.Point(135, 47);
            this.buttonG.Name = "buttonG";
            this.buttonG.Size = new System.Drawing.Size(22, 26);
            this.buttonG.TabIndex = 71;
            this.buttonG.Text = "G";
            this.buttonG.UseVisualStyleBackColor = true;
            // 
            // buttonZ
            // 
            this.buttonZ.Location = new System.Drawing.Point(23, 79);
            this.buttonZ.Name = "buttonZ";
            this.buttonZ.Size = new System.Drawing.Size(22, 26);
            this.buttonZ.TabIndex = 76;
            this.buttonZ.Text = "Z";
            this.buttonZ.UseVisualStyleBackColor = true;
            // 
            // buttonF
            // 
            this.buttonF.Location = new System.Drawing.Point(107, 47);
            this.buttonF.Name = "buttonF";
            this.buttonF.Size = new System.Drawing.Size(22, 26);
            this.buttonF.TabIndex = 70;
            this.buttonF.Text = "F";
            this.buttonF.UseVisualStyleBackColor = true;
            // 
            // buttonD
            // 
            this.buttonD.Location = new System.Drawing.Point(79, 47);
            this.buttonD.Name = "buttonD";
            this.buttonD.Size = new System.Drawing.Size(22, 26);
            this.buttonD.TabIndex = 69;
            this.buttonD.Text = "D";
            this.buttonD.UseVisualStyleBackColor = true;
            // 
            // buttonS
            // 
            this.buttonS.Location = new System.Drawing.Point(51, 47);
            this.buttonS.Name = "buttonS";
            this.buttonS.Size = new System.Drawing.Size(22, 26);
            this.buttonS.TabIndex = 68;
            this.buttonS.Text = "S";
            this.buttonS.UseVisualStyleBackColor = true;
            // 
            // buttonA
            // 
            this.buttonA.Location = new System.Drawing.Point(23, 47);
            this.buttonA.Name = "buttonA";
            this.buttonA.Size = new System.Drawing.Size(22, 26);
            this.buttonA.TabIndex = 67;
            this.buttonA.Text = "A";
            this.buttonA.UseVisualStyleBackColor = true;
            // 
            // buttonP
            // 
            this.buttonP.Location = new System.Drawing.Point(262, 15);
            this.buttonP.Name = "buttonP";
            this.buttonP.Size = new System.Drawing.Size(22, 26);
            this.buttonP.TabIndex = 66;
            this.buttonP.Text = "P";
            this.buttonP.UseVisualStyleBackColor = true;
            // 
            // buttonO
            // 
            this.buttonO.Location = new System.Drawing.Point(234, 15);
            this.buttonO.Name = "buttonO";
            this.buttonO.Size = new System.Drawing.Size(22, 26);
            this.buttonO.TabIndex = 65;
            this.buttonO.Text = "O";
            this.buttonO.UseVisualStyleBackColor = true;
            // 
            // buttonI
            // 
            this.buttonI.Location = new System.Drawing.Point(206, 15);
            this.buttonI.Name = "buttonI";
            this.buttonI.Size = new System.Drawing.Size(22, 26);
            this.buttonI.TabIndex = 64;
            this.buttonI.Text = "I";
            this.buttonI.UseVisualStyleBackColor = true;
            // 
            // buttonU
            // 
            this.buttonU.Location = new System.Drawing.Point(178, 15);
            this.buttonU.Name = "buttonU";
            this.buttonU.Size = new System.Drawing.Size(22, 26);
            this.buttonU.TabIndex = 63;
            this.buttonU.Text = "U";
            this.buttonU.UseVisualStyleBackColor = true;
            // 
            // buttonY
            // 
            this.buttonY.Location = new System.Drawing.Point(151, 15);
            this.buttonY.Name = "buttonY";
            this.buttonY.Size = new System.Drawing.Size(22, 26);
            this.buttonY.TabIndex = 62;
            this.buttonY.Text = "Y";
            this.buttonY.UseVisualStyleBackColor = true;
            // 
            // buttonT
            // 
            this.buttonT.Location = new System.Drawing.Point(123, 15);
            this.buttonT.Name = "buttonT";
            this.buttonT.Size = new System.Drawing.Size(22, 26);
            this.buttonT.TabIndex = 61;
            this.buttonT.Text = "T";
            this.buttonT.UseVisualStyleBackColor = true;
            // 
            // buttonR
            // 
            this.buttonR.Location = new System.Drawing.Point(95, 15);
            this.buttonR.Name = "buttonR";
            this.buttonR.Size = new System.Drawing.Size(22, 26);
            this.buttonR.TabIndex = 60;
            this.buttonR.Text = "R";
            this.buttonR.UseVisualStyleBackColor = true;
            // 
            // buttonE
            // 
            this.buttonE.Location = new System.Drawing.Point(67, 15);
            this.buttonE.Name = "buttonE";
            this.buttonE.Size = new System.Drawing.Size(22, 26);
            this.buttonE.TabIndex = 59;
            this.buttonE.Text = "E";
            this.buttonE.UseVisualStyleBackColor = true;
            // 
            // buttonW
            // 
            this.buttonW.Location = new System.Drawing.Point(39, 15);
            this.buttonW.Name = "buttonW";
            this.buttonW.Size = new System.Drawing.Size(22, 26);
            this.buttonW.TabIndex = 58;
            this.buttonW.Text = "W";
            this.buttonW.UseVisualStyleBackColor = true;
            // 
            // buttonQ
            // 
            this.buttonQ.Location = new System.Drawing.Point(11, 15);
            this.buttonQ.Name = "buttonQ";
            this.buttonQ.Size = new System.Drawing.Size(22, 26);
            this.buttonQ.TabIndex = 1;
            this.buttonQ.Text = "Q";
            this.buttonQ.UseVisualStyleBackColor = true;
            this.buttonQ.Click += new System.EventHandler(this.buttonQ_Click);
            // 
            // panelGame
            // 
            this.panelGame.AutoSize = true;
            this.panelGame.Location = new System.Drawing.Point(0, 0);
            this.panelGame.Margin = new System.Windows.Forms.Padding(0);
            this.panelGame.Name = "panelGame";
            this.panelGame.Size = new System.Drawing.Size(988, 600);
            this.panelGame.TabIndex = 0;
            this.panelGame.Paint += new System.Windows.Forms.PaintEventHandler(this.panelGame_Paint);
            this.panelGame.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.panelGame_PreviewKeyDown);
            // 
            // Game
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.ClientSize = new System.Drawing.Size(984, 681);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panelGame);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.Name = "Game";
            this.Text = "Game";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonM;
        private System.Windows.Forms.Button buttonL;
        private System.Windows.Forms.Button buttonN;
        private System.Windows.Forms.Button buttonK;
        private System.Windows.Forms.Button buttonB;
        private System.Windows.Forms.Button buttonV;
        private System.Windows.Forms.Button buttonJ;
        private System.Windows.Forms.Button buttonC;
        private System.Windows.Forms.Button buttonH;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.Button buttonG;
        private System.Windows.Forms.Button buttonZ;
        private System.Windows.Forms.Button buttonF;
        private System.Windows.Forms.Button buttonD;
        private System.Windows.Forms.Button buttonS;
        private System.Windows.Forms.Button buttonA;
        private System.Windows.Forms.Button buttonP;
        private System.Windows.Forms.Button buttonO;
        private System.Windows.Forms.Button buttonI;
        private System.Windows.Forms.Button buttonU;
        private System.Windows.Forms.Button buttonY;
        private System.Windows.Forms.Button buttonT;
        private System.Windows.Forms.Button buttonR;
        private System.Windows.Forms.Button buttonE;
        private System.Windows.Forms.Button buttonW;
        private System.Windows.Forms.Button buttonQ;
        private System.Windows.Forms.Panel panelGame;
        private System.Windows.Forms.Button buttonEnter;
    }
}